<?php

session_start();

$userdb ='root';

$passdb ="";

$database="id3474029_aes";

$hostdb='localhost';

?>