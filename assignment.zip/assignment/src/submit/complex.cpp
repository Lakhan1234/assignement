#include<iostream>
#include "complex.hpp"
using namespace std;

/* Default Constructor initialises Class 

Complex();  //Default Constructor
    Complex(int,int);   //Parameterised Constructor
    int Addition(Complex a);
    int Substraction(Complex a);
    int Multiplication(Complex a);
    int Division(Complex a);
    void display();

*/

Complex::Complex()  //first complex is class and second complex is method name
{
    real=5;
    imaginary=8;
}
Complex::Complex(int real,int imaginary)// first Complex is class and second Complex is method name with parameterised constructor
{
    this->real=real;
    this->imaginary=imaginary;
}
void Complex::display()
{
    cout<<"\nreal"<<real;
    cout<<"\nimaginary"<<imaginary;
}
Complex Complex::operator+(Complex a)
{
    Complex c;
    c.real=real+a.real;
    c.imaginary=imaginary+a.imaginary;
    //return (Complex((real+a.real),(imaginary+a.imaginary)));
    return c;
}
Complex Complex::operator-(Complex a)
{
    Complex c;
    c.real=real-a.real;
    c.imaginary=imaginary-a.imaginary;
    //return (Complex((real+a.real),(imaginary+a.imaginary)));
    return c;
}



