#include<iostream>
using namespace std;
class Complex
{
    public : int real,imaginary;
    Complex();  //Default Constructor
    Complex(int,int);   //Parameterised Constructor
    //Complex Addition(Complex a);
    int Substraction(Complex a);
    int Multiplication(Complex a);
    int Division(Complex a);
    void display();
    
    Complex operator +(Complex);
    Complex operator -(Complex);
   // ~Complex();     //Destructor 
};

