<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=login.php">
<title>AES - ISSC</title>
<script language="javascript">
    window.location.href = "login.php"
</script>
</head>
<body>
Go to <a href="login.php">login.php</a>
</body>
</html>
