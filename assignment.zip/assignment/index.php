<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=src/login.php">
<title>AES - ISSC</title>
<script language="javascript">
    window.location.href = "src/login.php"
</script>
</head>
<body>
Go to <a href="src/login.php">/src/login.php</a>
</body>
</html>
